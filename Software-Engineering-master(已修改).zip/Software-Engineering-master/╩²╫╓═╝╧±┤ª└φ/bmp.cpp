#include "stdafx.h"
BITMAPINFO* lpBitsInfo = NULL;

BOOL LoadBmpFile(char* BmpFileName)
{
	FILE* fp;
	if(NULL == (fp = fopen(BmpFileName,"rb")))
		return FALSE;
	
	BITMAPFILEHEADER bf;	//�ļ�ͷ
	BITMAPINFOHEADER bi;	//��Ϣͷ

	//���ļ�ͷBITMAPFILEHEADER�ṹ���ļ��ж�������д��bf��
	fread(&bf,14,1,fp);

	//���ļ�ͷBITMAPINFOHEADER�ṹ���ļ��ж�������д��bf��
	fread(&bi,40,1,fp);

	//ʵ���õ�����ɫ��������ɫ�������е���ɫ����
	DWORD NumColors;
	if(bi.biClrUsed != 0)
		NumColors = bi.biClrUsed;
	else {
		switch(bi.biBitCount)
		{
		case 1:
			NumColors = 2;
			break;
		case 2:
			NumColors = 24;
			break;
		case 4:
			NumColors = 16;
			break;
		case 8:
			NumColors = 256;
			break;
		case 24:
			NumColors = 0;
			break;
		}
	}

	DWORD LineBytes = (bi.biWidth * bi.biBitCount + 31)/32 * 4;

	DWORD ImgSize = LineBytes * bi.biHeight;

	DWORD size = 40 + NumColors * 4 + ImgSize;
	
	if(NULL== (lpBitsInfo = (BITMAPINFO*)malloc(size) ))
		return NULL;

	//�ļ�ָ�����¶�λ��BITMAPINFOHEADER��ʼ��
	fseek(fp, sizeof (BITMAPFILEHEADER),SEEK_SET);
	
	//���ļ����ݶ���lpBitsInfo
	fread( (char*) lpBitsInfo,size, 1, fp);
	fclose(fp);
	lpBitsInfo->bmiHeader.biClrUsed = NumColors;
	
	return TRUE;
}

void gray()
{
    int w = lpBitsInfo->bmiHeader.biWidth;
	int h = lpBitsInfo->bmiHeader.biHeight;
	int LineBytes = (w * lpBitsInfo->bmiHeader.biBitCount + 31)/32 * 4;
	BYTE* lpBits = (BYTE*)&lpBitsInfo->bmiColors[lpBitsInfo->bmiHeader.biClrUsed];
	int LineBytesgray=(w*8+31)/32*4;
	int size=40+1024+LineBytesgray*h;
    BITMAPINFO *lpNew = (BITMAPINFO*)malloc(size);
	memcpy(lpNew,lpBitsInfo,40);
	lpNew->bmiHeader.biClrUsed=256;
    lpNew->bmiHeader.biBitCount=8;
	for(int i=0;i<256;i++)
	{
		lpNew->bmiColors[i].rgbBlue=i;
		lpNew->bmiColors[i].rgbGreen=i;
        lpNew->bmiColors[i].rgbRed=i;
		lpNew->bmiColors[i].rgbReserved=0;
	}
	BYTE* lpNewBits = (BYTE*)&lpNew->bmiColors[lpNew->bmiHeader.biClrUsed];

	int x,y;
	BYTE *R, *G, *B, avg;
	for (x = 0; x < h; x ++)
	{
		for (y = 0; y < w; y ++)
		{
			// ָ�����ص�(i,j)��ָ��
			B = lpBits + LineBytes * (h - 1 - x) + y * 3;
			G = B + 1;
			R = G + 1;
			avg = (*R + *G + *B)/3;
			*R = *G = *B = avg;
			*(lpNewBits + LineBytesgray * (h - 1 - x) + y)=avg;
		}
	}
	free(lpBitsInfo);
	lpBitsInfo=lpNew;
}

DWORD HB[256];
DWORD HG[256];
DWORD HR[256];
void Histogram()     //����ֱ��ͼ;
{
	int w = lpBitsInfo->bmiHeader.biWidth;
	int h = lpBitsInfo->bmiHeader.biHeight;
	int LineBytes = (w * lpBitsInfo->bmiHeader.biBitCount + 31)/32 * 4;
	BYTE* lpBits = (BYTE*)&lpBitsInfo->bmiColors[lpBitsInfo->bmiHeader.biClrUsed];
	BYTE *pixel;
	int i,j;
	for(i=0;i<h;i++)
	{
		for(j=0;j<w;j++)
		{
	        pixel=lpBits + LineBytes * (h - 1 - i) + j;
			HB[lpBitsInfo->bmiColors[*pixel].rgbBlue]++;
            HG[lpBitsInfo->bmiColors[*pixel].rgbGreen]++;
			HR[lpBitsInfo->bmiColors[*pixel].rgbRed]++;
		}
	}

}